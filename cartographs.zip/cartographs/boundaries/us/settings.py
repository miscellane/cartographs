
class Settings:

    def __init__(self):

        # For geographic boundaries
        self.crs = 4269
        self.latest = 2018
